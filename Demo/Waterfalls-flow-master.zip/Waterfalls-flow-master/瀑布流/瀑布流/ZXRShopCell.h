//
//  ZXRShopCell.h
//  瀑布流
//
//  Created by zuo on 15/8/12.
//  Copyright (c) 2015年 zuo. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ZXRShop;

@interface ZXRShopCell : UICollectionViewCell
@property (nonatomic, strong) ZXRShop *shop;
@end
